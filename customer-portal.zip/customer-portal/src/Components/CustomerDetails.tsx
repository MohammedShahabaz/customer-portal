import React from 'react';
import PhotoGrid from './PhotoGrid';
interface Customer {
  id: number;
  name: string;
  title: string;
  address: string;
}

interface Props {
  customer: Customer | null;
}

const CustomerDetails: React.FC<Props> = ({ customer }) => {
  if (!customer) {
    return <div className="customer-details">Select a customer to see details</div>;
  }

  return (
    <div className="customer-details">
      <h2>{customer.name}</h2>
      <p><strong>Title:</strong> {customer.title}</p>
      <p><strong>Address:</strong> {customer.address}</p>
      <PhotoGrid />
    </div>
  );
};

export default CustomerDetails;
