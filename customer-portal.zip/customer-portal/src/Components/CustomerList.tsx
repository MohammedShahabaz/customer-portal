import React from 'react';
import { FixedSizeList as List, ListChildComponentProps } from 'react-window';
import CustomerCard from './CustomerCard';

interface Customer {
  id: number;
  name: string;
  title: string;
}

interface Props {
  customers: Customer[];
  selectedCustomerId: number;
  onSelectCustomer: (id: number) => void;
}

const CustomerList: React.FC<Props> = ({ customers, selectedCustomerId, onSelectCustomer }) => {

  const Row = ({ index, style }: ListChildComponentProps) => {
    const customer = customers[index];

    return (
      <div style={style} className={`list-item ${customer.id === selectedCustomerId ? 'selected' : ''}`}>
        <CustomerCard
          key={customer.id}
          customer={customer}
          isSelected={customer.id === selectedCustomerId}
          onSelect={() => onSelectCustomer(customer.id)}
        />
      </div>
    );
  };

  return (
    <List
      className="customer-list"
      height={730}
      itemCount={customers.length}
      itemSize={100}
      width={'30%'}
    >
      {Row}
    </List>
  );
};

export default CustomerList;
