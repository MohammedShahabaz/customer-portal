import React, { useState, useEffect } from 'react';
import CustomerList from './Components/CustomerList';
import CustomerDetails from './Components/CustomerDetails';
import './App.css';
import axios from 'axios';

interface Customer {
  id: number;
  name: string;
  title: string;
  address: string;
}

const App: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(null);

  useEffect(() => {
    const fetchCustomers = async () => {
      const response = await axios.get('http://localhost:5000/customers');
      console.log(response)
      setCustomers(response.data);
    };
    fetchCustomers();
  }, []);

  const selectedCustomer = customers.find((c) => c.id === selectedCustomerId);

  return (
    <div className="app">
      <CustomerList
        customers={customers}
        selectedCustomerId={selectedCustomerId!}
        onSelectCustomer={setSelectedCustomerId}
      />
      <CustomerDetails customer={selectedCustomer || null} />
    </div>
  );
};

export default App;
