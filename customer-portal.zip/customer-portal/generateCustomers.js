const fs = require('fs');

const generateCustomers = () => {
  const customers = [];

  for (let i = 1; i <= 1000; i++) {
    customers.push({
      id: i,
      name: `Customer ${i}`,
      title: `Title ${i}`,
      address: `123 Main St, City ${i}, Country`,
    });
  }

  return { customers };
};

const data = generateCustomers();

fs.writeFileSync('db.json', JSON.stringify(data, null, 2));
